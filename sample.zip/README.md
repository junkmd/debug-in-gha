# win_upterm_env_comtypes

## 目的

GitHub Actions の Windows ランナーに`upterm`で入り、母艦の VS Code (Remote-SSH) でリポジトリ `D:\a\debug-in-gha\debug-in-gha` を開いてデバッグする。

## 動作構成

```
┌─────────────────┐
│ Host VS Code    │
└────────┬────────┘
         │ SSH (Port 2222)
         ▼
┌────────────────────────┐
│ 127.0.0.1:2222         │
│ (Tunnel Entry)         │
└────────┬───────────────┘
         │ ssh -N -L 2222:127.0.0.1:22 <token>@uptermd.upterm.dev
         ▼
┌─────────────────┐
│ upterm          │
│ (Tunnel Server) │
└────────┬────────┘
         │ Tunnel Forward
         ▼
┌────────────────────────┐
│ Runner 127.0.0.1:22    │
│ (sshd)                 │
└────────────────────────┘
```

- upterm は「トンネル」としてだけ使用
- VS Code は通常の sshd に接続する

> **Note**: ランナー側に VS Code をインストールしていません。母艦の VS Code (Remote-SSH) から接続するため、ランナー側には `sshd` と公開鍵のみが必要です。

## 必要なセットアップ(最初に一度だけ)

### 公開鍵の登録(リポジトリ Secrets)

公開鍵をリポジトリの **Settings → Secrets and variables → Actions → Secrets** に `SSH_PUBKEY` として登録しておく。workflow の Setup sshd ステップで `${{ secrets.SSH_PUBKEY }}` として参照される。

### 母艦側の初期設定(初回のみ)

1. ssh-agent を有効化(管理者 PowerShell)し、通常の PowerShell で鍵を登録する。
   ```powershell
   Get-Service ssh-agent | Set-Service -StartupType Automatic
   Start-Service ssh-agent
   ssh-add $env:USERPROFILE\.ssh\id_ed25519
   ```
2. `.ssh/config` にホストを追加する。
   ```
   Host runner
       HostName 127.0.0.1
       Port 2222
       User runneradmin
       IdentityFile ~/.ssh/id_ed25519
       IdentitiesOnly yes
       StrictHostKeyChecking no
       UserKnownHostsFile NUL
   ```
   - `HostName`は **`upterm`ではなく `127.0.0.1`(トンネルの入口)** です。
   - 接続先を`upterm`のホスト名で書かないのがポイントです。
   - この内容は毎回同じなので、一度書いたら編集不要です。


## 毎回の接続手順(いつもやること)

### 1. トンネルを張る（ウィンドウA）

**通常の PowerShell** を開き、以下を実行して開いたままにする。

```powershell
ssh -N -L 2222:127.0.0.1:22 <今回のトークン>@uptermd.upterm.dev
```

- `<今回のトークン>` は Actions のログ（upterm のステップ）に表示される接続文字列から取る
- このウィンドウを閉じると VS Code の接続も切れる

### 2. VS Code で接続する

1. `F1` → **Remote-SSH: Connect to Host...** → `runner` を選ぶ
2. OS は **Windows** を選ぶ
3. パスフレーズを聞かれたら入力（ssh-agent 登録済みならスキップ）
4. **フォルダーを開く** で `D:\a\debug-in-gha\debug-in-gha` を開く
5. 必要な拡張機能（Python など）を「SSH: runner にインストール」で入れる

## つながらない場合

### 1. まず SSH 単体で疎通確認する

VS Code を介さず、ターミナルから直接接続を試す。

```powershell
ssh -v -p 2222 runneradmin@127.0.0.1
```

`-v` の出力で原因を切り分ける。

| 出力 | 考えられる原因 | 対処 |
|---|---|---|
| `Connection refused` | ランナーの sshd が未起動 | workflow の Setup sshd ステップが実行されているか確認 |
| `administratively prohibited` | `upterm`のポートフォワード許可不足 | workflow の `allow-forwarding: "loopback"` を確認 |
| `Offering public key` 直後に `Authentications that can continue: password` | 公開鍵認証が失敗 | `administrators_authorized_keys` の存在・中身・ACL を確認 |
| `Permission denied (publickey,password)` | 鍵が拒否された | 公開鍵のフィンガープリント(`ssh-keygen -lf`)で一致確認 |

### 2. SSH が通れば VS Code 設定を確認

- `.ssh/config` の `Host runner` が `HostName 127.0.0.1` / `Port 2222` になっているか
- VS Code の接続先が `runner` になっているか（`uptermd.upterm.dev` のままなら直結になっている）
- Remote-SSH のログ（出力パネル → 「リモート SSH」）の1行目が `ssh-remote+runner` で始まっているか

### 3. よくある失敗パターンと対処

| 現象 | 原因 | 対処 |
|---|---|---|
| `guest exec denied` | `upterm`既定でコマンド実行不可。`upterm`のシェルへ**直接** `ssh` / Remote-SSH した場合にだけ出る | 本構成では `allow-exec: true` は**不要**。`upterm`へ直接接続せず、上記のトンネル(`ssh -N -L ...`)経由で `127.0.0.1:2222` に接続する |
| `no sshd parent proc` |`upterm`シェルは sshd ではない | **upterm へ直接接続せず、sshd 経由のトンネル構成にする** |
| 公開鍵が効かない | `administrators_authorized_keys` 不在/ACL不正 | workflow の Setup sshd で作成・ACL設定・再起動まで実施 |
| パスフレーズを繰り返し聞かれる | ssh-agent 未起動/未登録 | `Start-Service ssh-agent` → `ssh-add` |
| 「存在しないパイプ」エラー | ssh-agent 通信失敗 | ssh-agent サービスを再起動、または `ssh-add` し直し |

> **`allow-exec` が不要な理由**: `allow-exec` は、`upterm`の guest が `upterm`経由でコマンドを実行する許可です。本構成で `upterm`に対して行うのはポートフォワード(`ssh -N -L`、コマンドなし)だけで、これは `allow-forwarding: "loopback"` で許可されます。コマンドの実行は、トンネルの先のランナーの `sshd` が公開鍵認証のうえで行うため、`upterm`の `allow-exec` の対象外です。

## 運用上の注意点

- トンネル用の `ssh -N -L ...` ウィンドウを閉じると VS Code 接続も切れる
-`upterm`の接続文字列(トークン)は外部に漏らさない
- ランナーのジョブ終了でセッションごと消える。再接続時はトークン取得→トンネル張り直し
- ランナーのホスト鍵は毎回変わる（`StrictHostKeyChecking no` / `UserKnownHostsFile NUL` で回避済み）
- 公開鍵のフィンガープリント(`ssh-keygen -lf`)を控えておくと貼り間違い防止になる

## テストダブル(CppTestSrv)のビルド・登録・テスト・登録解除

> **コマンド実行のルール**: このドキュメントに記載のコマンドは、書かれた形のまま実行してください。`tools\build_test_server.bat` や `cmd /c tools\build_test_server.bat` のようにパス区切りを `\` にしたり `cmd /c` を付けたりした形式は**許可されていません**。ディレクトリ移動とコマンド実行を分けて書いている場合（例: `cd tools` してから `build_test_server.bat`）、そのままの順序で実行してください。`&&` や `;` での連結、パイプ、リダイレクトも不必要に使わないでください。
>
> **Git コマンドについて**: 開発対象リポジトリは `src/` ディレクトリにあります。`git diff`、`git log`、`git status` などの Git コマンドを実行する際は、必ず `cd src` してから実行してください。ワークスペースルート（`d:/a/debug-in-gha/debug-in-gha`）ではワークスペース分しか Git が動作せず、ネストしている `src/` ディレクトリの内容は把握できません。

ランナー上（または VS Code のターミナル）で、リポジトリ直下から以下の順に実行する。

### 0. 前提: VS のインストールパスを確認

```cmd
vswhere -latest -property installationPath
```

出力された `{vswhere のパス}` を、次の手順の `vcvarsall.bat` のパスに使う（例: `C:\Program Files\Microsoft Visual Studio\18\Enterprise`）。

### 1. テストダブルのビルド

```cmd
cd tools
build_test_server.bat
```

`build_test_server.bat` が`vswhere`でVSのインストールパスを検出し（引数で指定した場合はそちらを優先）、`src\source\CppTestSrv` で`vcvarsall`と`nmake`を実行する。ビルド後、`Server.exe` が生成される。

> **トラブルシューティング**: ビルド時に `LINK : fatal error LNK1168: cannot open Server.exe for writing` エラーが発生した場合、前回の `Server.exe` がまだプロセスとして残っている可能性があります。以下のコマンドで強制終了してから再ビルドしてください。
>
> ```cmd
> taskkill /F /IM Server.exe
> ```

### 2. サーバー登録

```cmd
cd src\source\CppTestSrv
server.exe /RegServer
```

### 3. テスト実行

リポジトリ直下からテスト実行用バッチを呼ぶ（仮想環境の有効化とディレクトリ移動はバッチ内で行う）。

```cmd
cd tools
run_tests.bat
```

> テスト実行時にカバレッジ計測とレポート出力（コンソール・HTML）が同時に行われます。
> サーバーを登録した状態でないと、`test_variant_error` などの C++ サーバー依存テストが skip される。

### 4. サーバー登録解除

テスト完了後、必ず登録解除する。

```cmd
cd src\source\CppTestSrv
server.exe /UnregServer
```

> 登録解除を忘れると、テストダブルを変更後に再登録する際に競合する

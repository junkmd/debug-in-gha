@echo off
rem テストダブル (CppTestSrv/Server.exe) のビルド
rem
rem 使い方:
rem   build_test_server.bat                  VS のインストールパスを vswhere で自動検出
rem   build_test_server.bat "<VSインストールパス>"  検出結果を引数で指定 (例: C:\Program Files\Microsoft Visual Studio\18\Enterprise)

setlocal

rem --- 1. VS のインストールパスを決定 ---
set "VS_PATH=%~1"
if defined VS_PATH goto :have_vs_path

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" set "VSWHERE=vswhere"

for /f "usebackq delims=" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VS_PATH=%%i"

:have_vs_path
if not defined VS_PATH (
    echo [build_test_server] Visual Studio のインストールパスを取得できませんでした。
    echo                     引数で指定してください: build_test_server.bat "^<VSインストールパス^>"
    exit /b 1
)
echo [build_test_server] VS_PATH=%VS_PATH%

rem --- 2. vcvarsall.bat の存在確認 ---
set "VCVARS=%VS_PATH%\VC\Auxiliary\Build\vcvarsall.bat"
if not exist "%VCVARS%" (
    echo [build_test_server] vcvarsall.bat が見つかりません: %VCVARS%
    exit /b 1
)

rem --- 3. CppTestSrv ディレクトリへ移動 (スクリプトの位置基準) ---
cd /d "%~dp0..\src\source\CppTestSrv"
if errorlevel 1 (
    echo [build_test_server] CppTestSrv ディレクトリへ移動できませんでした。
    exit /b 1
)

rem --- 4. VS 環境を初期化してビルド ---
call "%VCVARS%" x64
if errorlevel 1 exit /b 1

nmake /f Makefile
exit /b %errorlevel%

@echo off
rem comtypes のテストを実行
rem リポジトリ直下の仮想環境を有効化してからテストを実行する

setlocal

rem --- 1. 仮想環境の有効化 ---
set "VENV_ACTIVATE=%~dp0..\.venv\Scripts\activate.bat"
if not exist "%VENV_ACTIVATE%" (
    echo [run_tests] 仮想環境が見つかりません: %VENV_ACTIVATE%
    echo             先に uv sync などで環境を作成してください。
    exit /b 1
)
call "%VENV_ACTIVATE%"
if errorlevel 1 (
    echo [run_tests] 仮想環境の有効化に失敗しました。
    exit /b 1
)

rem --- 2. src ディレクトリ (クローンした comtypes) へ移動 ---
cd /d "%~dp0..\src"
if errorlevel 1 (
    echo [run_tests] src ディレクトリへ移動できませんでした。
    exit /b 1
)

rem --- 3. テスト実行 ---
python -m coverage run -m unittest discover -s comtypes/test -t comtypes/test -v
python -m coverage report
python -m coverage html
exit /b %errorlevel%

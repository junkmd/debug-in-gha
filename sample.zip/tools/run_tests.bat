@echo off
rem comtypes のテストを実行
rem リポジトリ直下の仮想環境を有効化してからテストを実行する
rem テスト前後に COM サーバーの登録・登録解除を行う
rem
rem 使い方:
rem   run_tests.bat                  アーキテクチャを PROCESSOR_ARCHITECTURE から自動判定
rem   run_tests.bat x86              32ビット版として実行
rem   run_tests.bat x64              64ビット版として実行

setlocal

rem --- 0. アーキテクチャの決定 ---
set "ARCH=%~1"
if not defined ARCH (
    if "%PROCESSOR_ARCHITECTURE%"=="AMD64" (
        set "ARCH=x64"
    ) else (
        set "ARCH=x86"
    )
)
echo [run_tests] Architecture: %ARCH%

rem --- 1. 仮想環境の有効化 ---
set "VENV_ACTIVATE=%~dp0..\.venv\Scripts\activate.bat"
if not exist "%VENV_ACTIVATE%" (
    echo [run_tests] 仮想環境が見つかりません: %VENV_ACTIVATE%
    echo             先に uv sync などで環境を作成してください。
    exit /b 1
)
call "%VENV_ACTIVATE%"
if errorlevel 1 (
    echo [run_tests] 仮想環境の有効化に失敗しました。
    exit /b 1
)

rem --- 2. src ディレクトリ (クローンした comtypes) へ移動 ---
cd /d "%~dp0..\src"
if errorlevel 1 (
    echo [run_tests] src ディレクトリへ移動できませんでした。
    exit /b 1
)

rem --- 3. COM サーバーの登録 (テスト前) ---
echo [run_tests] COM サーバーの登録を実行します...

rem 3-1. CppTestSrv (Server.exe) の登録
cd /d "%~dp0..\src\source\CppTestSrv"
if not exist server.exe (
    echo [run_tests] エラー: Server.exe が見つかりません: %~dp0..\src\source\CppTestSrv\server.exe
    exit /b 1
)
echo [run_tests] Registering CppTestSrv (Server.exe)...
server.exe /RegServer
if errorlevel 1 (
    echo [run_tests] CppTestSrv の登録に失敗しました。
    exit /b 1
)

rem 3-2. AvmcIfc の登録 (アーキテクチャに応じて)
cd /d "%~dp0..\src\source\Avmc\Debug"
if "%ARCH%"=="x64" (
    if not exist AvmcIfc_x64.dll (
        echo [run_tests] エラー: AvmcIfc_x64.dll が見つかりません: %~dp0..\src\source\Avmc\Debug\AvmcIfc_x64.dll
        exit /b 1
    )
    echo [run_tests] Registering AvmcIfc_x64.dll...
    regsvr32 /s AvmcIfc_x64.dll
    if errorlevel 1 (
        echo [run_tests] AvmcIfc_x64.dll の登録に失敗しました。
        exit /b 1
    )
) else (
    if not exist AvmcIfc.dll (
        echo [run_tests] エラー: AvmcIfc.dll が見つかりません: %~dp0..\src\source\Avmc\Debug\AvmcIfc.dll
        exit /b 1
    )
    echo [run_tests] Registering AvmcIfc.dll...
    regsvr32 /s AvmcIfc.dll
    if errorlevel 1 (
        echo [run_tests] AvmcIfc.dll の登録に失敗しました。
        exit /b 1
    )
)

rem --- 4. テスト実行 ---
python -m coverage run -m unittest discover -s comtypes/test -t comtypes/test -v
python -m coverage report
python -m coverage html

rem --- 5. COM サーバーの登録解除 (テスト成否に関わらず実行) ---
echo [run_tests] COM サーバーの登録解除を実行します...

rem 5-1. CppTestSrv (Server.exe) の登録解除
cd /d "%~dp0..\src\source\CppTestSrv"
if not exist server.exe (
    echo [run_tests] エラー: Server.exe が見つかりません: %~dp0..\src\source\CppTestSrv\server.exe
    exit /b 1
)
echo [run_tests] Unregistering CppTestSrv (Server.exe)...
server.exe /UnregServer
if errorlevel 1 (
    echo [run_tests] CppTestSrv の登録解除に失敗しました。
    exit /b 1
)

rem 5-2. AvmcIfc の登録解除 (アーキテクチャに応じて)
cd /d "%~dp0..\src\source\Avmc\Debug"
if "%ARCH%"=="x64" (
    if not exist AvmcIfc_x64.dll (
        echo [run_tests] エラー: AvmcIfc_x64.dll が見つかりません: %~dp0..\src\source\Avmc\Debug\AvmcIfc_x64.dll
        exit /b 1
    )
    echo [run_tests] Unregistering AvmcIfc_x64.dll...
    regsvr32 /u /s AvmcIfc_x64.dll
    if errorlevel 1 (
        echo [run_tests] AvmcIfc_x64.dll の登録解除に失敗しました。
        exit /b 1
    )
) else (
    if not exist AvmcIfc.dll (
        echo [run_tests] エラー: AvmcIfc.dll が見つかりません: %~dp0..\src\source\Avmc\Debug\AvmcIfc.dll
        exit /b 1
    )
    echo [run_tests] Unregistering AvmcIfc.dll...
    regsvr32 /u /s AvmcIfc.dll
    if errorlevel 1 (
        echo [run_tests] AvmcIfc.dll の登録解除に失敗しました。
        exit /b 1
    )
)

echo [run_tests] 登録解除完了。
exit /b 0
